<%*
let list = {
  "3级标题及日期" : "<div class='entry-title'>\n<h3>标题</h3>\n<p>时间</p>\n</div>",
  "空格":"&emsp; ",
  "☎ 电话" : " <span class='icon'>&#xe60f; </span>",
  "✉ 邮箱" : " <span class='icon'>&#xe7ca; </span>",
  "github" : " <span class='icon'>&#xe600; </span>",
  "离职状态" : " <span class='icon'>&#xe8b5; </span>",
  "期望薪资" : " <span class='icon'>&#xe603; </span>",
  "期望岗位" : " <span class='icon'>&#xe638; </span>",
  "年龄" : " <span class='icon'>&#xe8b4; </span>",
  "城市" : " <span class='icon'>&#xe8ae; </span>",
  "项目经历" : " <span>&#xe635; </span>",
  "专业技能" : " <span>&#xe673; </span>",
  "教育经历" : " <span>&#xe80c; </span>",
  "工作经历" : " <span>&#xe618; </span>",
  "其他" : " <span>&#xecfa; </span>",
};
let keys = Object.keys(list);
key = await tp.system.suggester(keys, keys);
let value = list[key];
if (key) return  value ;
%>

| 图标                                               | unicode    | 分配     | 图标                                               | unicode    | 分配   |
| ------------------------------------------------ | ---------- | ------ | ------------------------------------------------ | ---------- | ---- |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-zx164x.png) | `&#xe60f;` | ☎ 电话   | ![\|50x50](./图片附件/cv_icon-2025-04-03-6wmnsi.png) | `&#xe7ca;` | ✉ 邮箱 |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-flxfnn.png) | `&#xe600;` | github | ![\|50x50](./图片附件/cv_icon-2025-04-03-ilv5pq.png) | `&#xe618;` | 工作经历 |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-5se2xc.png) | `&#xe80c;` | 教育经历   | ![\|50x50](./图片附件/cv_icon-2025-04-03-myzjk2.png) | `&#xecfa;` | 其他   |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-06b10j.png) | `&#xe69c;` |        | ![\|50x50](./图片附件/cv_icon-2025-04-03-xkyvs9.png) | `&#xe6b3;` |      |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-g56w7c.png) | `&#xe8ae;` | 位置     | ![\|50x50](./图片附件/cv_icon-2025-04-03-u8hq6f.png) | `&#xe782;` |      |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-jj079q.png) | `&#xe8b4;` | 年龄     | ![\|50x50](./图片附件/cv_icon-2025-04-03-2fvur1.png) | `&#xe603;` | 期望薪资 |
| ![\|50x50](./图片附件/cv_icon-2025-04-03-m3bjau.png) | `&#xe8b5;` | 离职状态   | ![\|50x47](./图片附件/cv_icon-2025-04-03-vyl8i8.png) | `&#xe638;` | 期望岗位 |
| ![\|50x47](./图片附件/cv_icon-2025-04-03-c9vpwu.png) | `&#xe635;` | 项目经历   | ![\|50x50](./图片附件/cv_icon-2025-04-03-8fkanq.png) | `&#xe673;` |      |

